import { 
  TrendingUp, 
  Target, 
  Clock, 
  CheckCircle,
  Zap
} from "lucide-react";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { GpaRing } from "@/components/dashboard/GpaRing";
import { TaskCard } from "@/components/dashboard/TaskCard";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { GpaCalculator } from "@/components/dashboard/GpaCalculator";
import { CourseCard } from "@/components/dashboard/CourseCard";

const tasks = [
  {
    title: "Data Structures Assignment 3",
    course: "CS201 - Data Structures",
    dueDate: "Tomorrow, 11:59 PM",
    priority: "high" as const,
    estimatedTime: "3 hours",
    progress: 65,
  },
  {
    title: "Machine Learning Quiz Prep",
    course: "CS405 - Machine Learning",
    dueDate: "Jan 26, 2:00 PM",
    priority: "medium" as const,
    estimatedTime: "2 hours",
    progress: 30,
  },
  {
    title: "Database Project Phase 2",
    course: "CS301 - Database Systems",
    dueDate: "Jan 28, 6:00 PM",
    priority: "high" as const,
    estimatedTime: "5 hours",
    progress: 10,
  },
  {
    title: "Operating Systems Lab Report",
    course: "CS302 - Operating Systems",
    dueDate: "Jan 30, 11:59 PM",
    priority: "low" as const,
    estimatedTime: "1.5 hours",
    progress: 0,
  },
];

const activities = [
  {
    id: "1",
    type: "deadline" as const,
    title: "Assignment Due Soon",
    description: "Data Structures Assignment 3 is due tomorrow",
    time: "2 hours ago",
    isNew: true,
  },
  {
    id: "2",
    type: "grade" as const,
    title: "Grade Posted",
    description: "You received an A in Machine Learning Midterm",
    time: "5 hours ago",
    isNew: true,
  },
  {
    id: "3",
    type: "announcement" as const,
    title: "Class Cancelled",
    description: "CS405 lecture on Friday has been cancelled",
    time: "1 day ago",
  },
  {
    id: "4",
    type: "submission" as const,
    title: "Submission Confirmed",
    description: "Your OS Lab 4 has been successfully submitted",
    time: "2 days ago",
  },
];

const courses = [
  {
    code: "CS201",
    name: "Data Structures & Algorithms",
    credits: 4,
    instructor: "Dr. Smith",
    progress: 68,
    nextClass: "Mon, 10:00 AM",
  },
  {
    code: "CS405",
    name: "Machine Learning",
    credits: 3,
    instructor: "Prof. Johnson",
    progress: 55,
    nextClass: "Tue, 2:00 PM",
  },
  {
    code: "CS301",
    name: "Database Systems",
    credits: 4,
    instructor: "Dr. Williams",
    progress: 42,
    nextClass: "Wed, 11:00 AM",
  },
  {
    code: "CS302",
    name: "Operating Systems",
    credits: 4,
    instructor: "Prof. Davis",
    progress: 75,
    nextClass: "Thu, 9:00 AM",
  },
];

export default function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 min-h-screen transition-all duration-300">
        <Header />
        
        <div className="p-6 space-y-6">
          {/* Stats Overview */}
          <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StatsCard
              title="Current CGPA"
              value="8.24"
              subtitle="Out of 10.0"
              icon={TrendingUp}
              trend={{ value: 2.5, isPositive: true }}
              variant="primary"
            />
            <StatsCard
              title="Target CGPA"
              value="8.50"
              subtitle="This semester goal"
              icon={Target}
              variant="accent"
            />
            <StatsCard
              title="Tasks Due"
              value="7"
              subtitle="4 this week"
              icon={Clock}
              variant="default"
            />
            <StatsCard
              title="Completed"
              value="23"
              subtitle="Tasks this month"
              icon={CheckCircle}
              trend={{ value: 15, isPositive: true }}
              variant="success"
            />
          </section>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* GPA Overview */}
              <section className="rounded-xl border border-border bg-card p-6">
                <div className="mb-6 flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-semibold">GPA Overview</h2>
                    <p className="text-sm text-muted-foreground">Your academic performance at a glance</p>
                  </div>
                </div>
                
                <div className="flex flex-wrap items-center justify-around gap-6">
                  <div className="text-center">
                    <GpaRing value={8.24} size="lg" label="CGPA" />
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <GpaRing value={8.67} size="sm" />
                      <div>
                        <p className="font-medium">Semester 5</p>
                        <p className="text-sm text-muted-foreground">Current</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <GpaRing value={8.12} size="sm" />
                      <div>
                        <p className="font-medium">Semester 4</p>
                        <p className="text-sm text-muted-foreground">Previous</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <GpaRing value={7.89} size="sm" />
                      <div>
                        <p className="font-medium">Semester 3</p>
                        <p className="text-sm text-muted-foreground">Completed</p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* What to do next */}
              <section className="rounded-xl border border-border bg-card p-6">
                <div className="mb-4 flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-accent">
                    <Zap className="h-4 w-4 text-accent-foreground" />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold">What to Do Next</h2>
                    <p className="text-sm text-muted-foreground">AI-prioritized tasks</p>
                  </div>
                </div>
                
                <div className="grid gap-3 md:grid-cols-2">
                  {tasks.map((task, index) => (
                    <TaskCard key={index} {...task} />
                  ))}
                </div>
              </section>

              {/* GPA Calculator */}
              <GpaCalculator currentCgpa={8.24} completedCredits={96} />
            </div>

            {/* Sidebar Content */}
            <div className="space-y-6">
              {/* Activity Feed */}
              <section className="rounded-xl border border-border bg-card p-6">
                <h2 className="mb-4 text-lg font-semibold">Recent Activity</h2>
                <ActivityFeed activities={activities} />
              </section>
            </div>
          </div>

          {/* Courses */}
          <section>
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">Your Courses</h2>
                <p className="text-sm text-muted-foreground">Current semester enrollment</p>
              </div>
              <button className="text-sm font-medium text-primary hover:underline">
                View All
              </button>
            </div>
            
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {courses.map((course, index) => (
                <CourseCard key={index} {...course} />
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
